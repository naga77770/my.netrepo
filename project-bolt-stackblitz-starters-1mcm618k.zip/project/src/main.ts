import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <div class="card">
        <h1 class="title">Welcome to Our Web App</h1>
        <p>This is a simple web application built with Angular {{ version }}</p>
        <button class="button" (click)="incrementCounter()">
          Clicked {{ counter }} times
        </button>
      </div>
    </div>
  `,
})
export class App {
  version = '19';
  counter = 0;

  incrementCounter() {
    this.counter++;
  }
}

bootstrapApplication(App);